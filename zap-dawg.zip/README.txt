Zapdawg.com Landing Page

Files:
- index.html
- styles.css
- logo.png (replace with pitbull lightning logo)
- README.txt

Deploy:
1. Create GitHub repo (public).
2. Upload these files.
3. Enable GitHub Pages in repo Settings → Pages → Source: main branch → root (/).
4. Set Porkbun DNS to GitHub Pages IPs + CNAME (www → yourusername.github.io).
